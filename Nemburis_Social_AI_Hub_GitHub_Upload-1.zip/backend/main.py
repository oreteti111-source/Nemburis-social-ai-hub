import os, sqlite3, json, datetime, re
from pathlib import Path
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import httpx

BASE=Path(__file__).resolve().parent.parent
DATA=BASE/"data"
DATA.mkdir(exist_ok=True)
DB=DATA/"nemburis.db"

app=FastAPI(title="NEMBURIS SOCIAL AI HUB")

def db():
    c=sqlite3.connect(DB)
    c.row_factory=sqlite3.Row
    return c

def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS leads(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, whatsapp TEXT, email TEXT, interest TEXT,
      travel_date TEXT, travelers INTEGER, budget TEXT, message TEXT,
      status TEXT DEFAULT 'New', source TEXT DEFAULT 'Website',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS content(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, platform TEXT,
      body TEXT, status TEXT DEFAULT 'Draft', scheduled_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS social_accounts(
      id INTEGER PRIMARY KEY AUTOINCREMENT, platform TEXT UNIQUE,
      account_name TEXT, status TEXT DEFAULT 'Not connected',
      access_token TEXT, connected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tasks(
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, due TEXT,
      done INTEGER DEFAULT 0
    );
    """)
    c.commit(); c.close()
init()

def fallback(topic, platform):
    p=platform
    return {
      "title":f"{topic} — NEMBURIS SAFARI TOURS",
      "hook":f"What if your next Tanzania journey became the story you never stop telling?",
      "caption":f"Discover {topic} with NEMBURIS SAFARI TOURS. Experience Tanzania with thoughtful planning, authentic moments and a journey designed around you.",
      "cta":"Send us an inquiry for your personalized Tanzania itinerary.",
      "hashtags":"#TanzaniaSafari #Serengeti #TanzaniaTravel #SafariTours #NemburisSafariTours",
      "script":f"0–5s: Strong visual of {topic}.\\n5–15s: Show the experience and explain why it matters.\\n15–25s: Show wildlife, landscape or culture.\\n25–30s: Invite viewers to inquire with NEMBURIS SAFARI TOURS."
    }

async def ai_generate(topic, platform):
    url=os.getenv("OLLAMA_URL")
    model=os.getenv("OLLAMA_MODEL","llama3.2")
    if not url:
        return fallback(topic,platform)
    prompt=f"""Create marketing content for NEMBURIS SAFARI TOURS.
Topic: {topic}
Platform: {platform}
Return concise JSON with keys title, hook, caption, cta, hashtags, script.
Do not invent prices or availability."""
    try:
        async with httpx.AsyncClient(timeout=30) as x:
            r=await x.post(url.rstrip("/")+"/api/generate",json={"model":model,"prompt":prompt,"stream":False})
            text=r.json().get("response","")
            m=re.search(r'\{.*\}',text,re.S)
            if m: return json.loads(m.group())
    except Exception: pass
    return fallback(topic,platform)

@app.get("/",response_class=HTMLResponse)
def home():
    return FileResponse(BASE/"frontend/index.html")

@app.get("/api/dashboard")
def dashboard():
    c=db()
    leads=c.execute("SELECT COUNT(*) n FROM leads").fetchone()["n"]
    hot=c.execute("SELECT COUNT(*) n FROM leads WHERE status='Hot'").fetchone()["n"]
    posts=c.execute("SELECT COUNT(*) n FROM content").fetchone()["n"]
    tasks=c.execute("SELECT COUNT(*) n FROM tasks WHERE done=0").fetchone()["n"]
    return {"leads":leads,"hot_leads":hot,"content":posts,"tasks":tasks}

@app.get("/api/leads")
def get_leads():
    c=db(); rows=c.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/leads")
def add_lead(data:dict):
    c=db()
    c.execute("""INSERT INTO leads(name,whatsapp,email,interest,travel_date,travelers,budget,message,source)
                 VALUES(?,?,?,?,?,?,?,?,?)""",
              (data.get("name"),data.get("whatsapp"),data.get("email"),data.get("interest"),
               data.get("travel_date"),data.get("travelers"),data.get("budget"),data.get("message"),
               data.get("source","Website")))
    c.commit()
    return {"ok":True}

@app.patch("/api/leads/{lead_id}")
def update_lead(lead_id:int,data:dict):
    c=db()
    c.execute("UPDATE leads SET status=? WHERE id=?",(data.get("status"),lead_id)); c.commit()
    return {"ok":True}

@app.get("/api/content")
def get_content():
    c=db(); return [dict(r) for r in c.execute("SELECT * FROM content ORDER BY id DESC").fetchall()]

@app.post("/api/content")
async def make_content(data:dict):
    result=await ai_generate(data.get("topic","Tanzania safari"),data.get("platform","Facebook"))
    c=db()
    c.execute("INSERT INTO content(title,platform,body,status) VALUES(?,?,?,?)",
              (result["title"],data.get("platform","Facebook"),json.dumps(result),"Draft"))
    c.commit()
    return result

@app.post("/api/content/save")
def save_content(data:dict):
    c=db(); c.execute("INSERT INTO content(title,platform,body,status,scheduled_at) VALUES(?,?,?,?,?)",
                       (data.get("title"),data.get("platform"),data.get("body"),data.get("status","Draft"),data.get("scheduled_at")))
    c.commit(); return {"ok":True}

@app.get("/api/social")
def socials():
    c=db()
    for p in ["Facebook","Instagram","TikTok","YouTube","WhatsApp Business","LinkedIn","X","Pinterest"]:
        c.execute("INSERT OR IGNORE INTO social_accounts(platform) VALUES(?)",(p,))
    c.commit()
    return [dict(r) for r in c.execute("SELECT id,platform,account_name,status,connected_at FROM social_accounts").fetchall()]

@app.post("/api/social/{platform}/configure")
def configure_social(platform:str,data:dict):
    c=db(); c.execute("UPDATE social_accounts SET account_name=?,status='Configured',connected_at=CURRENT_TIMESTAMP WHERE platform=?",
                      (data.get("account_name"),platform)); c.commit()
    return {"ok":True,"message":"Connector configured. Official OAuth/token setup is still required before publishing."}

@app.get("/api/tasks")
def tasks():
    c=db(); return [dict(r) for r in c.execute("SELECT * FROM tasks ORDER BY done,due").fetchall()]

@app.post("/api/tasks")
def add_task(data:dict):
    c=db(); c.execute("INSERT INTO tasks(title,due) VALUES(?,?)",(data.get("title"),data.get("due"))); c.commit(); return {"ok":True}

@app.patch("/api/tasks/{task_id}")
def complete_task(task_id:int):
    c=db(); c.execute("UPDATE tasks SET done=1 WHERE id=?",(task_id,)); c.commit(); return {"ok":True}

@app.post("/api/pdf")
def make_pdf(data:dict):
    title=data.get("title","Tanzania Travel Guide")
    body=data.get("body","")
    out=DATA/(re.sub(r'[^A-Za-z0-9_-]+','_',title)[:50]+".pdf")
    c=canvas.Canvas(str(out),pagesize=A4)
    w,h=A4; y=h-60
    c.setFont("Helvetica-Bold",18); c.drawString(50,y,title); y-=35
    c.setFont("Helvetica",10)
    for para in body.splitlines():
        words=para.split(); line=""
        for word in words:
            test=(line+" "+word).strip()
            if c.stringWidth(test,"Helvetica",10)>w-100:
                c.drawString(50,y,line); y-=15; line=word
                if y<60: c.showPage(); y=h-60; c.setFont("Helvetica",10)
            else: line=test
        if line: c.drawString(50,y,line); y-=18
        if y<60: c.showPage(); y=h-60; c.setFont("Helvetica",10)
    c.save()
    return FileResponse(out,media_type="application/pdf",filename=out.name)

@app.get("/inquire",response_class=HTMLResponse)
def inquire():
    return FileResponse(BASE/"frontend/inquire.html")

@app.post("/inquire")
def public_inquire(name:str=Form(...),whatsapp:str=Form(""),email:str=Form(""),
                   interest:str=Form(""),travel_date:str=Form(""),travelers:int=Form(1),
                   budget:str=Form(""),message:str=Form("")):
    add_lead({"name":name,"whatsapp":whatsapp,"email":email,"interest":interest,
              "travel_date":travel_date,"travelers":travelers,"budget":budget,"message":message,"source":"Public inquiry"})
    return HTMLResponse("<h2>Thank you. Your inquiry has been received.</h2><p>NEMBURIS SAFARI TOURS will follow up with you.</p><p><a href='/inquire'>Send another inquiry</a></p>")

app.mount("/static",StaticFiles(directory=BASE/"frontend"),name="static")
